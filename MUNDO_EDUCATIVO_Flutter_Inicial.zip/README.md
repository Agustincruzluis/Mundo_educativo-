# MUNDO EDUCATIVO — inicio del proyecto

Aplicación Flutter multiplataforma para estudiantes, docentes y familias.

## Plataformas objetivo
- Android
- iOS
- Windows
- macOS

## Requisitos
- Flutter SDK estable
- Android Studio para Android
- Xcode en macOS para compilar iOS y macOS
- Visual Studio con la carga de trabajo Desktop development with C++ para Windows

## Ejecutar
1. Instala Flutter y configura `flutter doctor`.
2. Descomprime este proyecto.
3. Abre una terminal en la carpeta `mundo_educativo_flutter`.
4. Ejecuta:

```bash
flutter pub get
flutter run
```

## Generar compilaciones
```bash
flutter build apk
flutter build ios
flutter build windows
flutter build macos
```

La compilación iOS/macOS requiere macOS y Xcode. La compilación Windows requiere Windows y Visual Studio.

## Estado actual
Esta es una maqueta funcional inicial de interfaz. Los botones de módulos muestran avisos porque todavía no se han conectado a una base de datos ni a servicios reales.

## Próximas etapas
1. Autenticación y roles (estudiante, docente, padre/tutor, administrador).
2. Base de datos y permisos.
3. Cursos, clases y evaluaciones.
4. Tutor IA con controles de seguridad y privacidad.
5. Chat y notificaciones.
6. Pagos, comprobantes y panel financiero.
