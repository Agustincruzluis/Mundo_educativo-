import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const MundoEducativoApp());
}

class MundoEducativoApp extends StatelessWidget {
  const MundoEducativoApp({super.key});

  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF142B4A);
    const blue = Color(0xFF2563EB);

    return MaterialApp(
      title: 'MUNDO EDUCATIVO',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: blue,
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF5F7FB),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: navy,
          elevation: 0,
          centerTitle: false,
        ),
        cardTheme: CardTheme(
          color: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFE7ECF3)),
          ),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
