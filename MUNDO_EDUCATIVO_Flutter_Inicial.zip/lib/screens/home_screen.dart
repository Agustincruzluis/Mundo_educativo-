import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedIndex = 0;

  final sections = const [
    _SectionData('Inicio', Icons.home_rounded),
    _SectionData('Cursos', Icons.menu_book_rounded),
    _SectionData('Tutor IA', Icons.auto_awesome_rounded),
    _SectionData('Mensajes', Icons.chat_bubble_outline_rounded),
    _SectionData('Mi progreso', Icons.insights_rounded),
  ];

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width >= 850;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: const Color(0xFFE8F0FF),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.school_rounded, color: Color(0xFF2563EB)),
            ),
            const SizedBox(width: 10),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('MUNDO EDUCATIVO',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                Text('Aprender. Crecer. Lograr.',
                    style: TextStyle(fontSize: 11, color: Colors.blueGrey)),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Notificaciones',
            onPressed: () => _showMessage('Las notificaciones estarán disponibles en la siguiente etapa.'),
            icon: const Icon(Icons.notifications_none_rounded),
          ),
          const Padding(
            padding: EdgeInsets.only(right: 16),
            child: CircleAvatar(
              backgroundColor: Color(0xFFE8F0FF),
              child: Icon(Icons.person_outline, color: Color(0xFF2563EB)),
            ),
          ),
        ],
      ),
      body: Row(
        children: [
          if (wide) _sideNavigation(),
          Expanded(
            child: _pageContent(),
          ),
        ],
      ),
      bottomNavigationBar: wide
          ? null
          : NavigationBar(
              selectedIndex: selectedIndex,
              onDestinationSelected: (value) => setState(() => selectedIndex = value),
              destinations: sections.map((item) => NavigationDestination(
                icon: Icon(item.icon),
                label: item.title,
              )).toList(),
            ),
    );
  }

  Widget _sideNavigation() {
    return NavigationRail(
      selectedIndex: selectedIndex,
      onDestinationSelected: (value) => setState(() => selectedIndex = value),
      labelType: NavigationRailLabelType.all,
      backgroundColor: Colors.white,
      destinations: sections.map((item) => NavigationRailDestination(
        icon: Icon(item.icon),
        label: Text(item.title),
      )).toList(),
    );
  }

  Widget _pageContent() {
    if (selectedIndex != 0) {
      final title = sections[selectedIndex].title;
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.construction_rounded, size: 48, color: Color(0xFF2563EB)),
              const SizedBox(height: 12),
              Text(title, style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 8),
              const Text('Este módulo se desarrollará en la siguiente etapa.',
                  textAlign: TextAlign.center),
            ],
          ),
        ),
      );
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final maxWidth = constraints.maxWidth > 1200 ? 1120.0 : double.infinity;
        return Align(
          alignment: Alignment.topCenter,
          child: SizedBox(
            width: maxWidth,
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _welcomeBanner(),
                  const SizedBox(height: 24),
                  Text('Explora tu espacio educativo',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w800,
                        color: const Color(0xFF142B4A),
                      )),
                  const SizedBox(height: 14),
                  _roleGrid(),
                  const SizedBox(height: 24),
                  Text('Accesos rápidos',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w800,
                        color: const Color(0xFF142B4A),
                      )),
                  const SizedBox(height: 14),
                  _quickActions(),
                  const SizedBox(height: 24),
                  const Text(
                    'Tu aprendizaje comienza aquí. Próximamente encontrarás cursos, actividades y recursos para cada nivel.',
                    style: TextStyle(color: Colors.blueGrey, height: 1.5),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _welcomeBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF142B4A), Color(0xFF2563EB)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('BIENVENIDO A MUNDO EDUCATIVO',
              style: TextStyle(color: Color(0xFFBFDBFE), fontSize: 11,
                fontWeight: FontWeight.bold, letterSpacing: 1.2)),
          SizedBox(height: 12),
          Text('Aprende a tu ritmo.\nConstruye tu futuro.',
              style: TextStyle(color: Colors.white, fontSize: 27,
                fontWeight: FontWeight.w800, height: 1.15)),
          SizedBox(height: 10),
          Text('Un espacio para estudiantes, docentes y familias.',
              style: TextStyle(color: Colors.white70, fontSize: 14)),
        ],
      ),
    );
  }

  Widget _roleGrid() {
    final roles = [
      _RoleData('Primaria', 'Aprende jugando y explorando', Icons.palette_rounded, const Color(0xFFFFF1D6), const Color(0xFFB7791F)),
      _RoleData('Secundaria', 'Refuerza tus conocimientos', Icons.science_rounded, const Color(0xFFE5F2FF), const Color(0xFF2563EB)),
      _RoleData('Superior', 'Avanza en tu formación', Icons.school_rounded, const Color(0xFFEDE9FE), const Color(0xFF7C3AED)),
      _RoleData('Familias', 'Acompaña el aprendizaje', Icons.family_restroom_rounded, const Color(0xFFE3F8EF), const Color(0xFF168653)),
    ];

    return LayoutBuilder(builder: (context, box) {
      final columns = box.maxWidth > 700 ? 4 : 2;
      return GridView.count(
        crossAxisCount: columns,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1.35,
        children: roles.map((role) => Card(
          child: InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: () => _showMessage('${role.title}: el contenido de este nivel se configurará próximamente.'),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircleAvatar(
                    backgroundColor: role.background,
                    child: Icon(role.icon, color: role.foreground),
                  ),
                  const SizedBox(height: 10),
                  Text(role.title, style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text(role.subtitle, style: const TextStyle(fontSize: 11, color: Colors.blueGrey)),
                ],
              ),
            ),
          ),
        )).toList(),
      );
    });
  }

  Widget _quickActions() {
    final actions = [
      ('Ver cursos', Icons.play_circle_outline_rounded),
      ('Practicar', Icons.edit_note_rounded),
      ('Tutor IA', Icons.auto_awesome_rounded),
    ];
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: actions.map((action) => OutlinedButton.icon(
        onPressed: () => _showMessage('${action.$1} estará disponible cuando implementemos ese módulo.'),
        icon: Icon(action.$2),
        label: Text(action.$1),
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      )).toList(),
    );
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}

class _SectionData {
  final String title;
  final IconData icon;
  const _SectionData(this.title, this.icon);
}

class _RoleData {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color background;
  final Color foreground;
  const _RoleData(this.title, this.subtitle, this.icon, this.background, this.foreground);
}
